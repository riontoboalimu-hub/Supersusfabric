package id.rion.supersus;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static net.minecraft.server.command.CommandManager.*;

public class SuperSusMod implements ModInitializer {
    public static final String MOD_ID = "supersus";
    private static final Random RANDOM = new Random();
    private static final Map<UUID, Role> ROLES = new ConcurrentHashMap<>();
    private static final Map<UUID, UUID> VOTES = new ConcurrentHashMap<>();
    private static boolean gameRunning = false;
    private static boolean meetingOpen = false;
    private static int taskGoal = 5;

    enum Team { CREWMATE, IMPOSTOR, NEUTRAL }

    enum Role {
        DETEKTIF("Detektif", Team.CREWMATE, "Periksa petunjuk di sekitar pemain."),
        DOKTER("Dokter", Team.CREWMATE, "Lindungi satu pemain saat ronde berlangsung."),
        TEKNISI("Teknisi", Team.CREWMATE, "Selesaikan tugas perbaikan lebih cepat."),
        PENGAWAS("Pengawas", Team.CREWMATE, "Gunakan kamera keamanan."),
        ILMUWAN("Ilmuwan", Team.CREWMATE, "Periksa status pemain dengan pemindai."),
        PENIRU("Peniru", Team.IMPOSTOR, "Menyamar sebagai pemain lain."),
        PENYABOT("Penyabot", Team.IMPOSTOR, "Aktifkan sabotase."),
        PEMBURU("Pemburu", Team.IMPOSTOR, "Memiliki kemampuan eliminasi khusus."),
        PENGUNCI("Pengunci", Team.IMPOSTOR, "Mengunci pintu untuk sementara."),
        PENGHILANG_JEJAK("Penghilang Jejak", Team.IMPOSTOR, "Mengaburkan jejak aktivitas."),
        BADUT("Badut", Team.NEUTRAL, "Menang jika dikeluarkan melalui voting."),
        PENYINTAS("Penyintas", Team.NEUTRAL, "Menang jika bertahan sampai akhir."),
        PEMBURU_TARGET("Pemburu Target", Team.NEUTRAL, "Selesaikan target rahasia."),
        KOLEKTOR("Kolektor", Team.NEUTRAL, "Kumpulkan item khusus."),
        HANTU("Hantu", Team.NEUTRAL, "Selesaikan misi rahasia dan bertahan.");

        final String display;
        final Team team;
        final String description;
        Role(String display, Team team, String description) {
            this.display = display;
            this.team = team;
            this.description = description;
        }
    }

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(literal("supersus")
                .then(literal("start").requires(s -> s.hasPermissionLevel(2)).executes(ctx -> startGame(ctx.getSource().getServer(), ctx.getSource().getPlayer())))
                .then(literal("stop").requires(s -> s.hasPermissionLevel(2)).executes(ctx -> stopGame(ctx.getSource().getServer())))
                .then(literal("status").executes(ctx -> showStatus(ctx.getSource().getServer(), ctx.getSource().getPlayer())))
                .then(literal("role").executes(ctx -> showRole(ctx.getSource().getPlayer())))
                .then(literal("meeting").requires(s -> s.hasPermissionLevel(2)).executes(ctx -> openMeeting(ctx.getSource().getServer())))
                .then(literal("vote").then(argument("target", word()).suggests((c, b) -> {
                    for (ServerPlayerEntity p : c.getSource().getServer().getPlayerManager().getPlayerList()) b.suggest(p.getName().getString());
                    return b.buildFuture();
                }).executes(ctx -> castVote(ctx.getSource().getServer(), ctx.getSource().getPlayer(), ctx.getArgument("target", String.class)))))
                .then(literal("help").executes(ctx -> help(ctx.getSource().getPlayer())))
            );
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (gameRunning && meetingOpen && !server.getPlayerManager().getPlayerList().isEmpty()) {
                // Voting is resolved when every living online player has voted.
                long alive = server.getPlayerManager().getPlayerList().stream().filter(p -> ROLES.containsKey(p.getUuid())).count();
                if (VOTES.size() >= alive && alive > 0) resolveVotes(server);
            }
        });
    }

    private static int startGame(MinecraftServer server, ServerPlayerEntity caller) {
        List<ServerPlayerEntity> players = new ArrayList<>(server.getPlayerManager().getPlayerList());
        if (gameRunning) { caller.sendMessage(Text.literal("Pertandingan sudah berjalan."), false); return 0; }
        if (players.size() < 1) return 0;
        if (players.size() > 20) { caller.sendMessage(Text.literal("Maksimal 20 pemain termasuk bot."), false); return 0; }

        ROLES.clear(); VOTES.clear();
        Collections.shuffle(players);
        int count = players.size();
        int impostors = count == 1 ? 0 : Math.max(1, count / 4);
        int neutrals = count >= 5 ? Math.max(1, count / 7) : 0;
        int crew = count - impostors - neutrals;

        List<Role> crewRoles = rolesFor(Team.CREWMATE);
        List<Role> impRoles = rolesFor(Team.IMPOSTOR);
        List<Role> neutralRoles = rolesFor(Team.NEUTRAL);
        int index = 0;
        for (int i = 0; i < crew; i++) ROLES.put(players.get(index++).getUuid(), crewRoles.get(RANDOM.nextInt(crewRoles.size())));
        for (int i = 0; i < impostors; i++) ROLES.put(players.get(index++).getUuid(), impRoles.get(RANDOM.nextInt(impRoles.size())));
        for (int i = 0; i < neutrals; i++) ROLES.put(players.get(index++).getUuid(), neutralRoles.get(RANDOM.nextInt(neutralRoles.size())));

        gameRunning = true; meetingOpen = false;
        server.getPlayerManager().broadcast(Text.literal("=== SUPER SUS DIMULAI ===").formatted(Formatting.GOLD), false);
        server.getPlayerManager().broadcast(Text.literal("Pemain: " + count + " | Crewmate: " + crew + " | Impostor: " + impostors + " | Netral: " + neutrals), false);
        for (ServerPlayerEntity p : players) {
            Role r = ROLES.get(p.getUuid());
            p.sendMessage(Text.literal("ROLE KAMU: " + r.display).formatted(Formatting.YELLOW, Formatting.BOLD), false);
            p.sendMessage(Text.literal(r.description), false);
        }
        return 1;
    }

    private static List<Role> rolesFor(Team team) {
        List<Role> list = new ArrayList<>();
        for (Role role : Role.values()) if (role.team == team) list.add(role);
        return list;
    }

    private static int stopGame(MinecraftServer server) {
        gameRunning = false; meetingOpen = false; ROLES.clear(); VOTES.clear();
        server.getPlayerManager().broadcast(Text.literal("Pertandingan Super Sus dihentikan."), false);
        return 1;
    }

    private static int showStatus(MinecraftServer server, ServerPlayerEntity player) {
        if (player == null) return 0;
        player.sendMessage(Text.literal("Game: " + (gameRunning ? "Berjalan" : "Belum dimulai") +
            " | Meeting: " + (meetingOpen ? "Terbuka" : "Tertutup") +
            " | Pemain terdaftar: " + ROLES.size()), false);
        return 1;
    }

    private static int showRole(ServerPlayerEntity player) {
        if (player == null) return 0;
        Role role = ROLES.get(player.getUuid());
        if (role == null) player.sendMessage(Text.literal("Kamu belum mendapat role. Mulai dengan /supersus start."), false);
        else {
            player.sendMessage(Text.literal("Role: " + role.display + " (" + role.team + ")").formatted(Formatting.YELLOW), false);
            player.sendMessage(Text.literal(role.description), false);
        }
        return 1;
    }

    private static int openMeeting(MinecraftServer server) {
        if (!gameRunning) return 0;
        meetingOpen = true; VOTES.clear();
        server.getPlayerManager().broadcast(Text.literal("MEETING DIMULAI! Gunakan /supersus vote <nama>." ).formatted(Formatting.AQUA, Formatting.BOLD), false);
        return 1;
    }

    private static int castVote(MinecraftServer server, ServerPlayerEntity voter, String targetName) {
        if (!gameRunning || !meetingOpen || voter == null) return 0;
        ServerPlayerEntity target = server.getPlayerManager().getPlayer(targetName);
        if (target == null || !ROLES.containsKey(target.getUuid())) {
            voter.sendMessage(Text.literal("Target tidak ditemukan atau tidak ikut pertandingan."), false); return 0;
        }
        VOTES.put(voter.getUuid(), target.getUuid());
        voter.sendMessage(Text.literal("Vote kamu tercatat untuk " + targetName + "."), false);
        long alive = server.getPlayerManager().getPlayerList().stream().filter(p -> ROLES.containsKey(p.getUuid())).count();
        if (VOTES.size() >= alive) resolveVotes(server);
        return 1;
    }

    private static void resolveVotes(MinecraftServer server) {
        if (!meetingOpen) return;
        Map<UUID, Integer> tally = new HashMap<>();
        for (UUID target : VOTES.values()) tally.merge(target, 1, Integer::sum);
        UUID winner = null; int max = 0; boolean tie = false;
        for (Map.Entry<UUID, Integer> e : tally.entrySet()) {
            if (e.getValue() > max) { winner = e.getKey(); max = e.getValue(); tie = false; }
            else if (e.getValue() == max) tie = true;
        }
        if (winner == null || tie) server.getPlayerManager().broadcast(Text.literal("Voting seri! Tidak ada yang dikeluarkan."), false);
        else {
            ServerPlayerEntity eliminated = server.getPlayerManager().getPlayer(winner);
            Role role = ROLES.remove(winner);
            String name = eliminated == null ? "Pemain" : eliminated.getName().getString();
            server.getPlayerManager().broadcast(Text.literal(name + " mendapat suara terbanyak. Role: " + (role == null ? "?" : role.display)), false);
        }
        meetingOpen = false; VOTES.clear();
    }

    private static int help(ServerPlayerEntity player) {
        if (player == null) return 0;
        player.sendMessage(Text.literal("Perintah Super Sus: /supersus start, stop, status, role, meeting, vote <nama>."), false);
        return 1;
    }
}
