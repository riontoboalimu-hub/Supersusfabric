SUPER SUS FABRIC - FONDASI AWAL
Minecraft Java 1.20.1 | Fabric | Java 17

ISI VERSI 0.1.0
- Perintah /supersus start, stop, status, role, meeting, vote, help.
- Pembagian role acak untuk pemain online.
- 15 role dasar: 5 Crewmate, 5 Impostor, 5 Netral.
- Batas maksimal 20 pemain online.
- Voting dasar dan pengumuman pemain yang mendapat suara terbanyak.

PENTING
Ini adalah fondasi/prototipe awal, BUKAN mod Super Sus lengkap.
NPC bot, gerakan bot, tugas, kemampuan role, sabotase, sistem eliminasi
dalam gameplay, GUI meeting, dan kondisi kemenangan belum dibuat.
Versi ini belum boleh dianggap selesai untuk dimainkan sebagai game penuh.

CARA BUILD
1. Ekstrak ZIP di komputer atau lingkungan Android yang mendukung Gradle + JDK 17.
2. Jalankan: gradle build
3. File mod akan dibuat di build/libs/supersus-fabric-0.1.0.jar
4. Salin JAR ke folder mods pada instance Fabric Minecraft 1.20.1.
5. Pastikan Fabric API 1.20.1 juga terpasang.

PERINTAH DALAM GAME
/supersus start
/supersus stop
/supersus status
/supersus role
/supersus meeting
/supersus vote <nama>
/supersus help

CATATAN
Jumlah 5+5+5 adalah jumlah JENIS ROLE, bukan jumlah pemain tetap.
Pada versi awal, jumlah tim disesuaikan otomatis dengan jumlah pemain online.
