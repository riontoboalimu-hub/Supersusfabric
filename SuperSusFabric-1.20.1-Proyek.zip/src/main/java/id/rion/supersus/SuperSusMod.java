package id.rion.supersus;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.*;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class SuperSusMod implements ModInitializer {
    private static final List<String> ROLES = List.of(
        "Detektif", "Dokter", "Teknisi", "Pengawas", "Ilmuwan",
        "Peniru", "Penyabot", "Pemburu", "Pengunci", "Penghilang Jejak",
        "Badut", "Penyintas", "Pemburu Target", "Kolektor", "Hantu"
    );

    private static final Map<UUID, String> PLAYER_ROLES = new HashMap<>();
    private static final Map<UUID, UUID> VOTES = new HashMap<>();
    private static boolean meetingOpen = false;

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(literal("sus")
                .then(literal("start")
                    .requires(source -> source.hasPermissionLevel(2))
                    .executes(context -> startGame(context.getSource())))
                .then(literal("roles")
                    .executes(context -> showRole(context.getSource())))
                .then(literal("meeting")
                    .requires(source -> source.hasPermissionLevel(2))
                    .executes(context -> openMeeting(context.getSource())))
                .then(literal("vote")
                    .then(argument("player", StringArgumentType.word())
                        .executes(context -> vote(context.getSource(),
                            StringArgumentType.getString(context, "player")))))
                .then(literal("endmeeting")
                    .requires(source -> source.hasPermissionLevel(2))
                    .executes(context -> closeMeeting(context.getSource())))
            );
        });
    }

    private static int startGame(ServerCommandSource source) {
        MinecraftServer server = source.getServer();
        List<ServerPlayerEntity> players = new ArrayList<>(server.getPlayerManager().getPlayerList());
        if (players.isEmpty()) {
            source.sendError(Text.literal("Tidak ada pemain online."));
            return 0;
        }

        List<String> shuffledRoles = new ArrayList<>(ROLES);
        Collections.shuffle(shuffledRoles);
        PLAYER_ROLES.clear();
        VOTES.clear();
        meetingOpen = false;

        for (int i = 0; i < players.size(); i++) {
            String role = shuffledRoles.get(i % shuffledRoles.size());
            PLAYER_ROLES.put(players.get(i).getUuid(), role);
            players.get(i).sendMessage(Text.literal("§e[SUPER SUS] §fPeranmu: §b" + role), false);
        }

        server.getPlayerManager().broadcast(Text.literal(
            "§e[SUPER SUS] §aGame dimulai! " + players.size() + " pemain mendapat peran."
        ), false);
        return players.size();
    }

    private static int showRole(ServerCommandSource source) {
        if (source.getEntity() instanceof ServerPlayerEntity player) {
            String role = PLAYER_ROLES.get(player.getUuid());
            if (role == null) {
                source.sendError(Text.literal("Kamu belum mendapat peran. Minta admin mengetik /sus start."));
                return 0;
            }
            source.sendFeedback(() -> Text.literal("Peranmu: §b" + role), false);
            return 1;
        }
        source.sendError(Text.literal("Perintah ini hanya untuk pemain."));
        return 0;
    }

    private static int openMeeting(ServerCommandSource source) {
        meetingOpen = true;
        VOTES.clear();
        source.getServer().getPlayerManager().broadcast(
            Text.literal("§6[MEETING] §fDiskusi dimulai! Gunakan §e/sus vote <nama_pemain>§f."), false);
        return 1;
    }

    private static int vote(ServerCommandSource source, String targetName) {
        if (!meetingOpen) {
            source.sendError(Text.literal("Belum ada meeting. Admin dapat membuka dengan /sus meeting."));
            return 0;
        }
        if (!(source.getEntity() instanceof ServerPlayerEntity voter)) {
            source.sendError(Text.literal("Hanya pemain yang bisa voting."));
            return 0;
        }
        ServerPlayerEntity target = source.getServer().getPlayerManager().getPlayer(targetName);
        if (target == null) {
            source.sendError(Text.literal("Pemain '" + targetName + "' tidak ditemukan atau sedang offline."));
            return 0;
        }
        VOTES.put(voter.getUuid(), target.getUuid());
        source.sendFeedback(() -> Text.literal("Vote kamu tercatat untuk " + target.getName().getString() + "."), false);
        return 1;
    }

    private static int closeMeeting(ServerCommandSource source) {
        if (!meetingOpen) {
            source.sendError(Text.literal("Tidak ada meeting yang sedang berlangsung."));
            return 0;
        }
        meetingOpen = false;
        Map<UUID, Integer> counts = new HashMap<>();
        for (UUID target : VOTES.values()) counts.merge(target, 1, Integer::sum);
        UUID winner = counts.entrySet().stream()
            .max(Map.Entry.comparingByValue())
            .map(Map.Entry::getKey).orElse(null);

        if (winner == null) {
            source.getServer().getPlayerManager().broadcast(Text.literal("§6[MEETING] §fTidak ada vote."), false);
        } else {
            ServerPlayerEntity votedPlayer = source.getServer().getPlayerManager().getPlayer(winner);
            String name = votedPlayer == null ? "Pemain offline" : votedPlayer.getName().getString();
            int total = counts.get(winner);
            source.getServer().getPlayerManager().broadcast(
                Text.literal("§6[HASIL VOTE] §fSuara terbanyak: §c" + name + " §7(" + total + " vote)."), false);
        }
        return 1;
    }
}
