# Super Sus Fabric 1.20.1 — prototipe awal

## Cara build melalui GitHub
1. Ekstrak isi ZIP ini.
2. Upload **isi folder** (bukan folder luarnya) ke repository GitHub.
3. Buka tab Actions, pilih `Build Super Sus Fabric`, lalu jalankan `Run workflow`.
4. Jika berhasil, buka hasil workflow dan unduh artifact `SuperSusFabric-1.20.1`.
5. Ambil file `.jar` dari artifact ZIP dan pasang di folder `mods` bersama Fabric API untuk Minecraft Java 1.20.1.

## Perintah dalam game
- `/sus start` — admin/operator membagikan peran acak kepada pemain online.
- `/sus roles` — melihat peran sendiri.
- `/sus meeting` — admin membuka meeting.
- `/sus vote <nama_pemain>` — memberikan vote.
- `/sus endmeeting` — admin menutup meeting dan melihat hasil vote.

## Status fitur
Ini baru fondasi yang dapat dibangun: pembagian peran acak, pengecekan peran, meeting sederhana, dan voting.
Belum ada bot NPC yang bergerak/menyelesaikan tugas, kemampuan khusus 15 role, sabotase, tugas, eliminasi, GUI, atau kondisi kemenangan. Mode solo dengan bot dan gameplay lengkap masih perlu dikembangkan.
